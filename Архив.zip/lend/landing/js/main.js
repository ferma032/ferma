$(function() {



    function startTimer(duration) {
        var timer = duration,
            minutes, seconds;
        setInterval(function() {
            minutes = parseInt(timer / 60, 10)
            seconds = parseInt(timer % 60, 10);

            minutes = minutes < 10 ? "0" + minutes : minutes;
            seconds = seconds < 10 ? "0" + seconds : seconds;

            // document.querySelector('#hours').textContent = "00";
            // document.querySelector('#minutes').textContent = minutes;
            // document.querySelector('#seconds').textContent = seconds;

            document.querySelector('#hours2').textContent = "00";
            document.querySelector('#minutes2').textContent = minutes;
            document.querySelector('#seconds2').textContent = seconds;

            if (--timer < 0) {
                timer = duration;
            }
        }, 1000);
    }
    var mins = 60 * 45;
    startTimer(mins);


    $('[data-href]').on('click', function(){
    	$('html, body').animate({
    		scrollTop: $($(this).data('href')).offset().top
    	}, 800)
    })


    $('[type="tel"]').on('focus', function(){

    	!$(this).val() ? $(this).val('0'): false; 
    });

    $('[type="tel"]').on('blur', function(){

    	$(this).val() === '0' ? $(this).val(''): false; 
    })


})